var newText = document.querySelector(".container.content");

window.setTimeout(function() {
var resultText = text.replace(/The/g, " Replaced").replace(/the/g, " replaced");
newText.innerHTML = resultText;
}, 4000);

let text = newText.innerHTML;




