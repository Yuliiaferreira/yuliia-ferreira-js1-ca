
const RickAndMortUrl = "https://rickandmortyapi.com/api/";
const characterUrl = `${RickAndMortUrl}character/`;
//const detailsUrl = `${characterUrl}${id}`;

fetch(characterUrl)
    .then(function(response) {
        return response.json();
    })
    .then(function(json) {
        createHtml(json);
    })
    .catch(function(error) {
        console.log(error);
        // redirect to error.html
        document.location.href = "error.html";
    });

function createHtml(json) {
    const results = json.results;
    console.dir(results);
   
    const rowContainer = document.querySelector(".row.results");

    let html = "";

    results.forEach(function(result) {
        let imageUrl = "https://via.placeholder.com/300";
        if (result.image) {
              imageUrl = result.image;      
        } else if (result.image_background) {
            imageUrl = result.image_background;

        }
        // display unknown if the property is empty
        let ratingValue = "Unknown";
        if (result.type) {
            ratingValue = result.type;
        }

      html += `<div class="col-sm-6 col-md-4 col-lg-3"><div class="card">  
                    <img class="image" src= "${imageUrl}"; alt="${result.name}">  
                    <div class="details">
                        <h4 class="name">${result.name}</h4>
                        <p>Type: ${ratingValue}</p>    
                        <p>Episode count: ${result.episode.length}</p>                                  
                        <a class="btn btn-primary" href="details.html?id=${result.id}">Details</a>
                    </div></div>
                </div>`;
    })

   rowContainer.innerHTML = html;
}
