// get the query str
const queryString = document.location.search;
// get the params in q.str
const parameters = new URLSearchParams(queryString);

let id;
// retrieve the id parameter from the query string
if (parameters.has("id")) {
    // assign id to variable
    id = parameters.get("id");
} else {
    // redirect to index.html
    document.location.href = "index.html";
}
// add the id to URL
const RickAndMortUrl = "https://rickandmortyapi.com/api/";
const characterUrl = `${RickAndMortUrl}character/`;
const detailsUrl = `${characterUrl}${id}`;
// using URL
fetch(detailsUrl)
    .then(function(response) {
        return response.json();
    })
    .then(function(json) {
        createHtml(json);
    })
    .catch(function(error) {
        console.log(error);
        // redirect to error.html
        document.location.href = "error.html";
    });

function createHtml(json) {
    console.dir(json);
    const container = document.querySelector(".container.content");
    // image as backgroung
    const image = document.querySelector(".details-image");
    if (json.image) {
        image.src = json.image;
    } else if (json.image_background) {
        image.src = json.image_background;
    } else {
        image.src = "https://via.placeholder.com/250";
    }
    // image alt from name
    image.alt = json.name;
    // h1 name
    const name = document.querySelector("h1");
    name.innerHTML = json.name;
    // p status
    const status = document.querySelector("#status");
    status.innerHTML = json.status;
    // p species
    const species = document.querySelector("#species");
    species.innerHTML = json.species;
    // p origin name from object
    const origin = document.querySelector("#origin");
    origin.innerHTML = json.origin.name;
    // p location name from object
    const location = document.querySelector("#location");
    location.innerHTML = json.location.name;
    // title as name
    document.title = json.name;
}